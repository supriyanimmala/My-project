package com.example.myproject




import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

import kotlinx.android.synthetic.main.list_item.view.*
class MyCustomAdapter(val items: ArrayList<location>) :
    RecyclerView.Adapter<MyCustomAdapter.ViewHolder>() {
    class ViewHolder (itemView:View):RecyclerView.ViewHolder(itemView)
    {
        val loc_name=itemView.findViewById(R.id.list_item_text_view)as TextView
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyCustomAdapter.ViewHolder {
     val v=LayoutInflater.from(parent.context).inflate(R.layout.list_item,parent,false)
        return  ViewHolder(v)
    }

    override fun getItemCount(): Int {
    return items.size
    }


    override fun onBindViewHolder(holder:ViewHolder, position: Int) {
       val pos:location=items[position]
        holder.loc_name.text=pos.name
    }


}
/*class MyCustomAdapter(val items: List<location>, private val clickListener: (location) -> Unit) :
    RecyclerView.Adapter<MyCustomAdapter.ViewHolder>() {
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bind(person: location, clickListener: (location) -> Unit) {
            //   itemView.list_item_text_view.text = location.name
            val loc_name=itemView.findViewById(R.id.list_item_text_view)as TextView

            //   val textview: TextView=View.list_item_text_view

        }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_item, parent, false)
        return RecyclerView.ViewHolder(view)
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        viewHolder.bind(items[position], clickListener)
        val pos:location=items[position]
        viewHolder.loc_name.text=pos.name
    }


}
}*/