package com.example.myproject

data class location(val name: String)