package com.example.myproject

import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.app.ActivityCompat

import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions



import kotlinx.android.synthetic.main.activity_maps.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

          /*  val location1 = location("AndhraPradesh")
            val location2 = location("Banglore")
            val location3 = location("Delhi")
            val location4 = location("Mumbai")
            val location5 = location("Hyderabad")*/
       lateinit var location123:ArrayList<location>

        location123.add(location("Andhra pradesh"))
        location123.add(location("chennai"))
                location123.add(location("Delhi"))
           my_recycler_view.adapter=MyCustomAdapter(items = location123)
            my_recycler_view.layoutManager = LinearLayoutManager (this,LinearLayoutManager.HORIZONTAL,false)
            my_recycler_view.setHasFixedSize (true)
      //  location123.add(location("banglore"))

        }


    }

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var mMap: GoogleMap

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1
    }

    private fun setUpMap() {
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
            return setUpMap( )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        val btn_click_me = findViewById(R.id.myBtn) as Button
// set on-click listener
        btn_click_me.setOnClickListener {
            Toast.makeText(this@MapsActivity, "Takes To Product Catalogue", Toast.LENGTH_SHORT).show()
        }




        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

setUpMap( )
        //To set the zoom In and zoom out toolbars
        mMap.getUiSettings().setZoomControlsEnabled(true);


        // Add a marker in banglore and move the camera
        val Andhrapradesh = LatLng(15.9129, 79.7400)
        mMap.addMarker(MarkerOptions().position(Andhrapradesh).title("Smart Cellular in Andhrapradesh"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Andhrapradesh))
        val hyderabad = LatLng(17.3850, 78.4867)
        mMap.addMarker(MarkerOptions().position(hyderabad).title("Smart Cellular in hyderabad"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(hyderabad))
        val Banglore = LatLng(12.9716, 77.5946)
        mMap.addMarker(MarkerOptions().position(Banglore).title("Smart Cellular in Banglore"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Banglore))
        val Delhi = LatLng(28.7041, 77.1025)
        mMap.addMarker(MarkerOptions().position(Delhi).title("Smart Cellular in Delhi"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Delhi))
        val mumbai = LatLng(19.0760, 72.8777)
        mMap.addMarker(MarkerOptions().position(mumbai).title("Smart Cellular in mumbai"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(mumbai))


    }
}


